const BASE_URL = "http://127.0.0.1:5000";

function getArray() {
    let input = document.getElementById("numbers").value;
    return input.split(" ").map(Number);
}

async function compare() {
    let arr = getArray();
    let target = Number(document.getElementById("target").value);

    let res = await fetch(`${BASE_URL}/compare`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            array: arr,
            target: target
        })
    });

    let data = await res.json();

    document.getElementById("output").innerHTML = `
        🔹 List Search → ${data.list_time.toFixed(6)} sec → O(n) → Found: ${data.list_result}<br><br>
        🔹 Set Search → ${data.set_time.toFixed(6)} sec → O(1) → Found: ${data.set_result}<br><br>
        🔹 Unique Elements (Set): ${data.unique_elements}
    `;
}