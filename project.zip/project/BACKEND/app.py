from flask import Flask, request, jsonify
from flask_cors import CORS
import time

app = Flask(__name__)
CORS(app)

# -------- LIST SEARCH (LINEAR) -------- #
def list_search(arr, target):
    start = time.time()
    found = target in arr
    end = time.time()
    return found, end - start


# -------- SET SEARCH (HASHING) -------- #
def set_search(arr, target):
    my_set = set(arr)  # remove duplicates + hashing
    start = time.time()
    found = target in my_set
    end = time.time()
    return found, end - start


# -------- ROUTE -------- #
@app.route('/compare', methods=['POST'])
def compare():
    data = request.json
    arr = data['array']
    target = data['target']

    list_found, list_time = list_search(arr, target)
    set_found, set_time = set_search(arr, target)

    return jsonify({
        "list_time": list_time,
        "set_time": set_time,
        "list_result": list_found,
        "set_result": set_found,
        "unique_elements": list(set(arr))
    })


if __name__ == '__main__':
    app.run(debug=True)